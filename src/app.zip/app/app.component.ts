import { HtmlParser } from '@angular/compiler';
import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { NgForm, NgModel } from '@angular/forms';
import { AlertComponent } from './alert/alert.component';
import { AlertDirective } from './alert/selector.directive';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss',
  ]
})
export class AppComponent implements OnInit {
  genderOptions:string[] = ['male','female','other']
  image:any = "../assets/download.jpg" ;
  user = {
    image:'',
    email:'',
    username:'',
    firstName:'',
    lastName:'',
    phoneNumber:'',
    gender:''
  }
  @ViewChild(AlertDirective,{static:false}) alertDirective!:AlertDirective ;

  constructor(private viewContainerRef: ViewContainerRef) {

  }
  ngOnInit(): void {

  }
  getUploadedImage(event:any){
      let file = event.target.files[0] ;
      let reader = new FileReader();
      reader.onload = ()=>{
        this.image = reader.result ; 
      }
      reader.readAsDataURL(file);
  }
  singUp(signUpForm: NgForm) {
    if (signUpForm.valid){
      this.user.email =  signUpForm.value.email
      this.user.username =  signUpForm.value.username
      this.user.firstName =  signUpForm.value.firstName
      this.user.lastName =  signUpForm.value.lastName
      this.user.gender =  signUpForm.value.gender
      this.user.phoneNumber =  signUpForm.value.phoneNumber
      this.user.image = this.image
    }
    console.log(this.user);
    this.image ="../assets/download.jpg"; 
    signUpForm.reset();
    
  }
  showAlert(){
      const alertCmp = this.alertDirective.viewContainerRef ;
      alertCmp.clear();
      const componetRef = alertCmp.createComponent<AlertComponent>(AlertComponent)
      // componetRef.instance.data(binded Data) = values
      // componetRef.instance.event.subscribe() = values

      
      
  }

}
