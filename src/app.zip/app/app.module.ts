import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { GlobalDesginComponent } from './global-desgin/global-desgin.component';
import { SpotComponent } from './spot/spot.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AuthComponent } from './auth/auth.component';
import {HttpClientModule} from "@angular/common/http";
import { AlertComponent } from './alert/alert.component'
import { AlertDirective } from './alert/selector.directive';

@NgModule({
  declarations: [
    AppComponent,
    GlobalDesginComponent,
    SpotComponent,
    AuthComponent,
    AlertComponent,
    AlertDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
