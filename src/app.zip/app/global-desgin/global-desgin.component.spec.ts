import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GlobalDesginComponent } from './global-desgin.component';

describe('GlobalDesginComponent', () => {
  let component: GlobalDesginComponent;
  let fixture: ComponentFixture<GlobalDesginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GlobalDesginComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GlobalDesginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
