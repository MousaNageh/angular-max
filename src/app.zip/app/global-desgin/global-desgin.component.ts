import { Component, ElementRef, OnInit, ViewChild ,OnChanges,DoCheck, SimpleChanges,AfterContentInit,AfterContentChecked,AfterViewInit,AfterViewChecked, ContentChild} from '@angular/core';

@Component({
  selector: 'app-global-desgin',
  templateUrl: './global-desgin.component.html',
  styleUrls: ['./global-desgin.component.scss'],

})
export class GlobalDesginComponent implements OnInit ,OnChanges,DoCheck,AfterContentInit,AfterContentChecked ,AfterViewInit,AfterViewChecked{
  @ViewChild('getH1', { static: true }) getH1!: ElementRef;
  @ViewChild('parentVal', { static: true }) parentVal!: ElementRef;
  @ViewChild('childerVal',{static:true})childerVal!:ElementRef;
  val:string ='' ;
  arr:string[]=[];

  constructor() {
    console.log("constructor");
  }
  ngOnInit(): void {
  //     console.log("ngOnInit");
  //     console.log("form  parent : ",this.parentVal);
  //     console.log("from parent : ",this.childerVal);
  }
  ngOnChanges(changes:SimpleChanges){
        // console.log("#########################") 
        // console.log(changes); 
  }
  ngDoCheck(){
    // console.log("ngDoCheck");
  }
  getRef(getH1: HTMLElement) {
    // console.log(getH1.offsetTop);
  }
  ngAfterContentInit(){
      console.log("form  parent : this is parent",this.parentVal);
      console.log("from parent : this is child ",this.childerVal);
  }
  ngAfterContentChecked(){
    // console.log("AfterContentChecked");
  }
  ngAfterViewInit(){
    // console.log("ngAfterViewInit");
    // console.log("form  parent : ",this.parentVal);
    //   console.log("from parent : ",this.childerVal);
    
  }
  ngAfterViewChecked(){
    // console.log("ngAfterViewChecked");
  }
  addVal(){
    this.arr.push(this.val);
    this.val = '' ;
  }
}
