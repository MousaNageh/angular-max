import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject, tap } from 'rxjs';
import { User } from './user.model';

interface AuthInterFace{
  kind:string ;
  idToken:string ; 
  email:string ; 
  refreshToken:string ; 
  expiresIn:string ; 
  localId:string ; 
  registered?:boolean
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  apiKey:string  = "AIzaSyAZP5nby347Ha8pVp1F0YEkZwDJ6VUD7FA";
  user = new Subject<User>() ;
  
  constructor(private http:HttpClient) { }
  singUp(data:any){
    return   this.http.post<AuthInterFace>("https://identitytoolkit.googleapis.com/v1/accounts:signUp",{
              email:data.email,
              password:data.password,
              returnSecureToken:true
            },{
              headers:{
                "Content-Type": "application/json"
              },
              params: new HttpParams().set("key",this.apiKey)
            })
  }
  login(data:any){
    return this.http.post<AuthInterFace>("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword",data,{
      params:new HttpParams().set("key",this.apiKey)
    }).pipe(tap((res)=>{
        this.handleAuth(res.email,res.localId,res.idToken,res.expiresIn)
    }))
  }

  private handleAuth(email:string,id:string,token:string, date:string ){
    const Expiredate = new Date(new Date().getTime() + parseInt(date) * 1000 )
    const user = new User(email,id,token,Expiredate)
    this.user.next(user) ; 
  } 
}
