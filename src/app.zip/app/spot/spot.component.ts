import { AfterContentInit, Component, ContentChild, ElementRef, OnInit, ViewChild ,AfterViewInit} from '@angular/core';

@Component({
  selector: 'app-spot',
  templateUrl: './spot.component.html',
  styleUrls: ['./spot.component.scss']
})
export class SpotComponent implements OnInit,AfterContentInit {

  @ContentChild('parentVal', { static: true }) parentVal!: ElementRef;
  @ViewChild('childerVal',{static:true})childerVal!:ElementRef;
  constructor() { }

  ngOnInit(): void 
  {
    // console.log("form  child : ",this.parentVal);
    // console.log("from child : ",this.childerVal);
  }
  ngAfterContentInit() {
    console.log("form  child : this is parent : ",this.parentVal);
    console.log("from child : this is child :",this.childerVal);
      
  }
  ngAfterViewInit(){
    // console.log("form  child : this is parent : ",this.parentVal);
    // console.log("from child : this is child :",this.childerVal);
  }
}
