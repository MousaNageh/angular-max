import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthService } from './auth.service';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.scss']
})
export class AuthComponent implements OnInit {
  isLoginModel:boolean = true ;
  isLoading:boolean=false ;
  isEmailExist:boolean=false ;

  constructor(private authService:AuthService) { }

  ngOnInit(): void {
  }
  submitAuthForm(form:NgForm){
    let  formVal = form.value 
    if (form.valid){
      
      this.isLoading = true 
      if(this.isLoginModel){
        this.authService.login(form.value).subscribe(res=>{
          console.log(res)
          this.isLoading = false ; 
        },error=>{
          this.isLoading = false ; 
          console.log(error)
        })
      }
      else{
        this.authService.singUp(form.value).subscribe(
          res=>{
            console.log(res)
            form.reset()
            this.isLoading = false ; 
            this.isEmailExist=false ; 
          },
          (err)=>{
            console.log(err.error.error) ;
            if(err.error.error.code==400 && err.error.error.message=="EMAIL_EXISTS")
            this.isEmailExist=true ; 
            this.isLoading = false ; 
          })
      }
    }
  }


}
